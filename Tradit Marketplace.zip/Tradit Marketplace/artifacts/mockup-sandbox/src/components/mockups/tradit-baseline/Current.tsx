import { ArrowRight, ArrowUpRight, Footprints, Plus } from 'lucide-react';
import './_group.css';

type Product = {
  id: string;
  brand: string;
  name: string;
  category: string;
  sizeRange: string;
  color: string;
  price: number;
  originalPrice: number;
  imageUrl: string;
  badge: string | null;
};

const products: Product[] = [
  { id: 'p1', brand: 'Nike', name: "Air Force 1 '07", category: 'Sneakers', sizeRange: '6–13', color: 'Summit White / Gum', price: 78, originalPrice: 115, imageUrl: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 520"%3E%3Crect width="640" height="520" fill="%23E8D8C4"/%3E%3Ccircle cx="516" cy="88" r="78" fill="%23B85C38" opacity=".18"/%3E%3Cpath d="M122 332c56-12 95-39 129-84l43-57c11-15 35-11 40 7l25 87c6 21 23 36 45 40l115 22c20 4 36 21 36 42v14H95v-24c0-22 8-39 27-47Z" fill="%23F6F1EA"/%3E%3Cpath d="M96 401h459c0 22-18 40-40 40H114c-10 0-18-8-18-18v-22Z" fill="%23B85C38"/%3E%3Cpath d="M265 194c30 17 55 28 83 34M245 224c37 17 68 27 103 32M229 255c37 14 69 23 105 27" stroke="white" stroke-width="9" stroke-linecap="round" opacity=".82"/%3E%3C/svg%3E', badge: 'Most loved' },
  { id: 'p2', brand: 'New Balance', name: '550 Heritage', category: 'Sneakers', sizeRange: '5–12', color: 'Sea Salt / Red', price: 92, originalPrice: 130, imageUrl: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 520"%3E%3Crect width="640" height="520" fill="%23D8E0D5"/%3E%3Ccircle cx="516" cy="88" r="78" fill="%23A6342E" opacity=".18"/%3E%3Cpath d="M122 332c56-12 95-39 129-84l43-57c11-15 35-11 40 7l25 87c6 21 23 36 45 40l115 22c20 4 36 21 36 42v14H95v-24c0-22 8-39 27-47Z" fill="%23F3EEE5"/%3E%3Cpath d="M96 401h459c0 22-18 40-40 40H114c-10 0-18-8-18-18v-22Z" fill="%23A6342E"/%3E%3Cpath d="M265 194c30 17 55 28 83 34M245 224c37 17 68 27 103 32M229 255c37 14 69 23 105 27" stroke="white" stroke-width="9" stroke-linecap="round" opacity=".82"/%3E%3C/svg%3E', badge: 'Fresh drop' },
  { id: 'p3', brand: 'Salomon', name: 'XT-6 Expanse', category: 'Outdoor', sizeRange: '7–13', color: 'Black / Desert Sage', price: 110, originalPrice: 160, imageUrl: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 520"%3E%3Crect width="640" height="520" fill="%23B9C8C2"/%3E%3Ccircle cx="516" cy="88" r="78" fill="%23D0A94C" opacity=".18"/%3E%3Cpath d="M122 332c56-12 95-39 129-84l43-57c11-15 35-11 40 7l25 87c6 21 23 36 45 40l115 22c20 4 36 21 36 42v14H95v-24c0-22 8-39 27-47Z" fill="%23202826"/%3E%3Cpath d="M96 401h459c0 22-18 40-40 40H114c-10 0-18-8-18-18v-22Z" fill="%23D0A94C"/%3E%3Cpath d="M265 194c30 17 55 28 83 34M245 224c37 17 68 27 103 32M229 255c37 14 69 23 105 27" stroke="white" stroke-width="9" stroke-linecap="round" opacity=".82"/%3E%3C/svg%3E', badge: 'Trail ready' },
];

function Brand() {
  return <div className="flex items-center gap-3"><span className="brand-mark" aria-hidden="true"><span className="font-mono-brand text-[9px]">T</span></span><span className="brand-word text-[1.35rem]">tradit</span></div>;
}

function ProductCard({ product }: { product: Product }) {
  const discount = Math.round((1 - product.price / product.originalPrice) * 100);
  return <article className="product-card group">
    <div className="relative aspect-[1.1] overflow-hidden rounded-[1.45rem] bg-[#e9e1d8]">
      <img src={product.imageUrl} alt={`${product.brand} ${product.name}`} className="product-media h-full w-full object-cover" />
      <div className="absolute left-4 top-4 flex gap-2">
        {product.badge && <span className="rounded-full bg-[#203b35] px-3 py-1.5 font-mono-brand text-[10px] uppercase tracking-wider text-[#f5f0e9]">{product.badge}</span>}
        <span className="rounded-full bg-[#f5f0e9]/90 px-3 py-1.5 font-mono-brand text-[10px] uppercase tracking-wider text-[#203b35]">-{discount}%</span>
      </div>
      <button type="button" className="absolute bottom-4 right-4 grid h-11 w-11 place-items-center rounded-full bg-[#d99a7c] text-[#203b35]"><Plus size={19} /></button>
    </div>
    <div className="flex items-start justify-between gap-4 pt-4">
      <div><p className="font-mono-brand text-[10px] uppercase tracking-[.16em] text-[#718078]">{product.brand} · {product.category}</p><h3 className="mt-1 text-base font-bold tracking-[-.02em]">{product.name}</h3><p className="mt-1 text-xs text-[#718078]">{product.color} · {product.sizeRange}</p></div>
      <div className="text-right"><p className="font-mono-brand text-sm font-medium">${product.price.toFixed(2)}</p><p className="text-xs text-[#718078] line-through">${product.originalPrice.toFixed(2)}</p></div>
    </div>
  </article>;
}

export function Current() {
  return <div className="tradit-current min-h-screen">
    <header className="sticky top-0 z-40 border-b border-[#ded4c8]/70 bg-[#f5f0e9]/90 backdrop-blur-xl">
      <div className="mx-auto flex h-[76px] max-w-[1240px] items-center justify-between px-5 lg:px-8">
        <Brand />
        <nav className="hidden items-center gap-8 md:flex"><span className="text-sm font-semibold text-[#203b35]">Shop</span><span className="text-sm font-semibold text-[#718078]">Trade in</span><span className="text-sm font-semibold text-[#718078]">Your circle</span></nav>
        <div className="grid h-10 w-10 place-items-center rounded-full border border-[#ded4c8] text-[#203b35]"><Footprints size={18} /></div>
      </div>
    </header>
    <main>
      <section className="hero-surface overflow-hidden text-[#f5f0e9]">
        <div className="mx-auto grid max-w-[1240px] items-end gap-12 px-5 pb-20 pt-16 lg:grid-cols-[1.1fr_.9fr] lg:px-8 lg:pb-24 lg:pt-24">
          <div className="animate-rise">
            <p className="font-mono-brand text-[10px] uppercase tracking-[.23em] text-[#d99a7c]">A neighborhood footwear exchange</p>
            <h1 className="font-display mt-5 max-w-[650px] text-[clamp(3.6rem,8vw,7.6rem)] leading-[.88] tracking-[-.065em]">Wear it well.<br /><em className="text-[#d99a7c]">Pass it on.</em></h1>
            <p className="mt-7 max-w-md text-base leading-7 text-[#f5f0e9]/72">Find pairs with a past. Give yours a next chapter. Tradit keeps good footwear in the circle, where style and stewardship belong together.</p>
            <div className="mt-9 flex flex-wrap items-center gap-3"><span className="inline-flex items-center gap-2 rounded-full bg-[#d99a7c] px-5 py-3 text-sm font-bold text-[#203b35]">Browse the edit <ArrowRight size={16} /></span><span className="inline-flex items-center gap-2 rounded-full border border-[#f5f0e9]/25 px-5 py-3 text-sm font-bold text-[#f5f0e9]">Trade a pair <ArrowUpRight size={16} /></span></div>
          </div>
          <div className="relative hidden min-h-[390px] lg:block"><div className="absolute right-[13%] top-[7%] h-[260px] w-[260px] rotate-12 rounded-[45%_55%_48%_52%] border border-[#d99a7c]/30 bg-[#d99a7c]/10" /><div className="absolute right-[18%] top-[12%] flex h-[270px] w-[300px] -rotate-[14deg] items-center justify-center rounded-[48%_52%_45%_55%] bg-[#d99a7c] shadow-[24px_28px_0_rgb(22_59_49_/.35)]"><div className="h-[125px] w-[235px] rotate-[-4deg] rounded-[60%_35%_52%_43%] border-[16px] border-[#f1c7aa] bg-[#283e3a] shadow-[inset_0_-14px_0_#182c29]" /></div><span className="absolute bottom-8 left-4 max-w-[150px] font-display text-2xl leading-none text-[#d99a7c]">good things<br />keep moving</span></div>
        </div>
      </section>
      <section className="mx-auto max-w-[1240px] px-5 py-16 lg:px-8 lg:py-24">
        <div className="mb-10 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="font-mono-brand text-[10px] uppercase tracking-[.2em] text-[#718078]">Current rotation</p><h2 className="font-display mt-2 text-4xl tracking-[-.04em] sm:text-5xl">The edit</h2></div><div className="flex gap-2"><span className="rounded-full border border-[#203b35] bg-[#203b35] px-4 py-2 text-xs font-bold text-[#f5f0e9]">All pairs</span><span className="rounded-full border border-[#ded4c8] px-4 py-2 text-xs font-bold">Sneakers</span><span className="rounded-full border border-[#ded4c8] px-4 py-2 text-xs font-bold">Outdoor</span></div></div>
        <div className="grid grid-cols-1 gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">{products.map((product) => <ProductCard key={product.id} product={product} />)}</div>
      </section>
    </main>
  </div>;
}